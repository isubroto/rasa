# How do I apply for WAI Awards 2023 APAC?
= On Sunday, March 19, 2023, at midnight GMT (+5:30), applications must be submitted. To finish registration, please fill out the form at https://docs.google.com/forms/d/e/1FAIpQLSfu7pesYbIDHJy5kowoiTxcb7S_z1lfQcM957KxpIfkNbhV3w/viewform. For further information, please visit the WAI Awards 2023 APAC website at https://www.womeninai.co/waiawards2023apac or send an email to waiawards_apac@womeninai.co.
# When is the final deadline for submitting my entry?
=According to the application form the last date of submissino is midnight GMT (+5:30) Sunday 19 March 2023 Or visit this page to know the updated date of submission deadline. 
URL: https://docs.google.com/forms/d/e/1FAIpQLSfu7pesYbIDHJy5kowoiTxcb7S_z1lfQcM957KxpIfkNbhV3w/viewform
# If I was a finalist in 2021 or 2022, may I apply again?
=there are no restriction says in the website. So it should be yes.
# Is there a cost to enter?
=No accurate answer 
# Do I have to be nominated to apply?
=according to the website there are not such thing says to apply.
# What do I need to include in my entry?
=No accurate answer
# Do I have to be Asia-Pacific based?
=yes, for example, if you are form north america resion then you have a option for Apply to WAI Awards North America
# Is my submission confidential?
=yes, we think it must be confidential
# Can I enter more than one category?
=If you can you are welcome
# What happens after I submit?
=
# Will I receive feedback?
=
# What is the judging process?
=The panel of curated judges are fully independent and subject matter experts who will ensure an accurate, fair and transparent judging process.
The first phase of the judging process evaluates all applicants from which three finalists of each category are selected.

The second phase of the judging process identifies the winner of each category from the three selected category finalists, and the overall winner of the Grand Award - 'APAC WAI Innovator of the Year' followed by the two runners-up.
# If I am a finalist and I cannot travel to Sydney, what happens?
=
# Can I invite family and friends?
=
# Who pays for my visa and travel costs?
=
# Who in my country, can I ask for help or advice?
=
